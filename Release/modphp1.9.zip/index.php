<?php
 error_reporting(0);
/*------------------引入文件------------------*/
require 'config.php';
require 'lib/modphp.php';
require 'lib/moddb.php';
require 'lib/modrsa.php';

header("Content-Type: text/html;charset=utf-8");
/*------------------路由定义------------------*/
//Bind_View_File('/','demo/index.html');
if (!file_exists('install.lock')) {
	Bind_View_File('/','demo/wechat/setup.php');
	Bind_View_File('/setup','demo/wechat/setup.php');
	return;
}
Bind_View_File('/','demo/wechat/index.php');
Bind_View_File('/admin','demo/wechat/admin.php');
Bind_View_File('/edit','demo/wechat/edit.php');
Bind_View_File('/zhuce','demo/wechat/zhuce.php');

Bind_View_File('/push','demo/filedb/push.php');
Bind_View_File('/table','demo/filedb/table.php');


Bind_Error(404);
/*------------------业务代码------------------*/



?>