<?php
require 'modphp.php';
require 'lib/db.php';
header("Content-Type: text/html;charset=utf-8");

$index = new ModTempLate;

$con = new Modmysql;
$con->load('localhost','root','','modphp');
$jlj=$con->query('select * from user;');
$qm=json_encode($con->fetch_all($jlj));
echo $qm;
$row=json_decode($qm,true);
echo $row[0]['id'];
$con->clear($jlj);

$jlj=$con->exec('select * from user order by id desc;');
while ($row=$con->fetch_array($jlj)) {
	echo json_encode($row);
}
$con->clear($jlj);
$con->close();

$con = new Modsqlite;
$con->load('aa.db');
//$con->exec('create table user(id int primary key not null,user text);');
//echo $con->error();
$con->exec('insert into user (id,user) values (null,"1");');
echo $con->error();
$aaa=$con->query('select * from user order by id desc;');
print_r($con->fetch_all($aaa)) ;

$con->exit();
$index->show();
?>